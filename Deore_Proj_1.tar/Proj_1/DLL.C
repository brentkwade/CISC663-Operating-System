//doubly linked list program
#include<stdio.h>
#include<stdlib.h>
#include "dlllib.h"

int main()
{
	clrscr();
	head=NULL;
	menuPrint();
	getch();
	return(0);
}